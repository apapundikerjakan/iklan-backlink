'use client';
import { useState } from 'react';

export default function VideoPlayer({ video, settings }) {
  const [unlocked, setUnlocked] = useState(false);
  const [adClicked, setAdClicked] = useState(false);

  const directLink = settings?.directLink || '';

  function handleClick() {
    // Klik pertama: buka backlink iklan di tab baru (monetisasi), klik kedua: play video
    if (directLink && !adClicked) {
      setAdClicked(true);
      window.open(directLink, '_blank', 'noopener,noreferrer');
      // masih tampilkan thumbnail, user klik lagi untuk play (persis pola safelink)
      return;
    }
    setUnlocked(true);
  }

  return (
    <div className="video-content">
      <div id="player">
        {!unlocked ? (
          <div className="video-link" onClick={handleClick} style={{ cursor: 'pointer' }}>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img className="thumbnail" src={video.thumb} alt={video.title} />
          </div>
        ) : video.embed ? (
          <iframe
            id="videq_iframe"
            scrolling="no"
            frameBorder="0"
            allowFullScreen
            allow="fullscreen"
            src={video.embed}
          />
        ) : (
          <video
            id="videq_iframe"
            controls
            autoPlay
            playsInline
            src={video.file || ''}
            poster={video.thumb}
          />
        )}
      </div>
      {settings?.bannerBottom ? (
        <div style={{ background: '#0c0c12', padding: 12, textAlign: 'center' }} dangerouslySetInnerHTML={{ __html: settings.bannerBottom }} />
      ) : null}
      {settings?.popunderScript ? <div dangerouslySetInnerHTML={{ __html: settings.popunderScript }} /> : null}
    </div>
  );
}
